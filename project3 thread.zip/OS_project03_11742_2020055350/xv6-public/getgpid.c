#include "types.h"
#include "x86.h"
#include "defs.h"
#include "param.h"
#include "mmu.h"
#include "proc.h"
int 
sys_getgpid(void)
{
 	return myproc()->parent->parent->pid;
}


