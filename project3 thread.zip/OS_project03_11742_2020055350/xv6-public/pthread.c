#include "types.h"
#include "user.h"
#include "x86.h"


int thread_create(thread_t *thread, void *(*start_routine)(void*), void * arg)
{
	void *stack =malloc((uint)4096*2); // PGSIZE
	if((uint)stack<=0)
	{
		free(stack);
		return -1;
	}
	t_create(start_routine, arg, stack);
	if(*thread>0)
	return 0;
	return -1;
}


