typedef unsigned int   uint;
typedef unsigned short ushort;
typedef unsigned char  uchar;
typedef int thread_t;
typedef uint pde_t;
